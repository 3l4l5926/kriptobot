
from freqtrade.strategy import IntParameter, DecimalParameter

from QuantumMomentumStrategy import QuantumMomentumStrategy


class PairSpecificStrategy(QuantumMomentumStrategy):

    buy_rsi = IntParameter(
        40,
        70,
        default=46,
        space="buy"
    )

    short_rsi = IntParameter(
        30,
        70,
        default=47,
        space="buy"
    )

    trend_adx = IntParameter(
        20,
        45,
        default=36,
        space="buy"
    )

    sl_multiplier = DecimalParameter(
        1.0,
        4.0,
        default=1.408,
        space="sell"
    )

    tp_multiplier = DecimalParameter(
        2.0,
        7.0,
        default=7.928,
        space="sell"
    )
