
from freqtrade.strategy import (
    IntParameter,
    DecimalParameter
)

from QuantumMomentumStrategy import (
    QuantumMomentumStrategy
)


class PairSpecificStrategy(
    QuantumMomentumStrategy
):

    buy_rsi = IntParameter(
        35,
        55,
        default=38,
        space="buy"
    )

    short_rsi = IntParameter(
        45,
        65,
        default=46,
        space="buy"
    )

    trend_adx = IntParameter(
        20,
        40,
        default=38,
        space="buy"
    )

    sl_multiplier = DecimalParameter(
        1.2,
        4.0,
        decimals=3,
        default=2.883,
        space="sell"
    )

    tp_multiplier = DecimalParameter(
        2.5,
        8.0,
        decimals=3,
        default=6.395,
        space="sell"
    )

    minimal_roi = {
        "0": 100.0
    }

    stoploss = -0.99

    use_custom_stoploss = False
