
from freqtrade.strategy import IntParameter, DecimalParameter

from QuantumMomentumStrategy import QuantumMomentumStrategy


class PairSpecificStrategy(QuantumMomentumStrategy):

    buy_rsi = IntParameter(
        40,
        70,
        default=50,
        space="buy"
    )

    short_rsi = IntParameter(
        30,
        70,
        default=53,
        space="buy"
    )

    trend_adx = IntParameter(
        20,
        45,
        default=21,
        space="buy"
    )

    sl_multiplier = DecimalParameter(
        1.0,
        4.0,
        default=2.204,
        space="sell"
    )

    tp_multiplier = DecimalParameter(
        2.0,
        7.0,
        default=3.137,
        space="sell"
    )
