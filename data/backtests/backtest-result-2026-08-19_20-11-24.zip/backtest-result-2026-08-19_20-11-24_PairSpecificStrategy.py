
from freqtrade.strategy import (
    IntParameter,
    DecimalParameter
)

from QuantumMomentumStrategy import (
    QuantumMomentumStrategy
)


class PairSpecificStrategy(
    QuantumMomentumStrategy
):

    buy_rsi = IntParameter(
        35,
        55,
        default=35,
        space="buy"
    )

    short_rsi = IntParameter(
        45,
        65,
        default=58,
        space="buy"
    )

    trend_adx = IntParameter(
        20,
        40,
        default=26,
        space="buy"
    )

    sl_multiplier = DecimalParameter(
        1.2,
        4.0,
        decimals=3,
        default=2.624,
        space="sell"
    )

    tp_multiplier = DecimalParameter(
        2.5,
        8.0,
        decimals=3,
        default=7.492,
        space="sell"
    )
